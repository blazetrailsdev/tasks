import { describe, expect, it } from "vitest";
import {
  validateApp,
  GID,
  MissingModelIdError,
  InvalidComponentError,
  BadURIError,
} from "./uri/gid.js";

// Mirrors the private assertion helpers on URI::GIDValidationTest /
// URI::GIDAppValidationTest (vendor/globalid/test/cases/uri_gid_test.rb:143-171).
// Mirrors minitest's `assert_raise(Klass) { ... }`, which returns the raised
// error so a following `assert_match` can read its message. Vitest's
// `toThrow` doesn't hand the error back.
function assertRaise(klass: new (...args: never[]) => Error, block: () => unknown): Error {
  try {
    block();
  } catch (e) {
    expect(e).toBeInstanceOf(klass);
    return e as Error;
  }
  throw new Error(`expected ${klass.name} to be raised`);
}

function assertInvalidComponent(uri: string): void {
  expect(() => GID.parse(uri)).toThrow(InvalidComponentError);
}

function assertBadUri(uri: string): void {
  expect(() => GID.parse(uri)).toThrow(BadURIError);
}

function assertInvalidApp(value: string | null): void {
  expect(() => validateApp(value)).toThrow();
}

describe("URI::GIDTest", () => {
  it("parsed", () => {
    const gid = GID.parse("gid://bcx/Person/5");
    expect(gid.app).toBe("bcx");
    expect(gid.modelName).toBe("Person");
    expect(gid.modelId).toBe("5");
    const cpkGid = GID.parse("gid://bcx/CompositePrimaryKeyModel/tenant-key-value/id-value");
    expect(cpkGid.modelId).toEqual(["tenant-key-value", "id-value"]);
  });

  it("parsed for non existing model class", () => {
    const flatGid = GID.parse("gid://bcx/NonExistingModel/1");
    expect(flatGid.modelId).toBe("1");
    expect(flatGid.modelName).toBe("NonExistingModel");
    const compositeGid = GID.parse("gid://bcx/NonExistingModel/tenant-key-value/id-value");
    expect(compositeGid.modelId).toEqual(["tenant-key-value", "id-value"]);
    expect(compositeGid.modelName).toBe("NonExistingModel");
  });

  it("create", () => {
    const uri = GID.build({ app: "bcx", modelName: "Person", modelId: "5" }).toString();
    expect(uri).toBe("gid://bcx/Person/5");
  });

  it("create from a composite primary key model", () => {
    const uri = GID.build({
      app: "bcx",
      modelName: "CompositePrimaryKeyModel",
      modelId: ["tenant-key-value", "id-value"],
    }).toString();
    expect(uri).toBe("gid://bcx/CompositePrimaryKeyModel/tenant-key-value/id-value");
  });

  it("build", () => {
    const a = GID.build({ app: "bcx", modelName: "Person", modelId: "5" }).toString();
    const b = GID.build({ app: "bcx", modelName: "Person", modelId: "5" }).toString();
    expect(a).toBeTruthy();
    expect(b).toBeTruthy();
    expect(a).toBe(b);
  });

  it("build with a composite primary key", () => {
    const a = GID.build({
      app: "bcx",
      modelName: "CompositePrimaryKeyModel",
      modelId: ["tenant-key-value", "id-value"],
    }).toString();
    const b = GID.build({
      app: "bcx",
      modelName: "CompositePrimaryKeyModel",
      modelId: ["tenant-key-value", "id-value"],
    }).toString();
    expect(a).toBeTruthy();
    expect(b).toBeTruthy();
    expect(a).toBe(b);
    expect(a).toBe("gid://bcx/CompositePrimaryKeyModel/tenant-key-value/id-value");
  });

  it("as String", () => {
    const gidStr = "gid://bcx/Person/5";
    const gid = GID.parse(gidStr);
    expect(
      GID.build({ app: gid.app, modelName: gid.modelName, modelId: gid.modelId }).toString(),
    ).toBe(gidStr);
  });

  it("equal", () => {
    const gid = GID.parse("gid://bcx/Person/5");
    expect(gid).toEqual(GID.parse("gid://bcx/Person/5"));
    expect(gid).not.toEqual(GID.parse("gid://bcxxx/Persona/1"));
  });

  it("build with wrong ordered array creates a wrong ordered gid", () => {
    // Rails: URI::GID.build(['Person', '5', 'bcx', nil]) misorders the
    // positional (app, modelName, modelId, params) tuple. The resulting
    // URI is not equal to the canonical gid://bcx/Person/5.
    expect(GID.build({ app: "Person", modelName: "5", modelId: "bcx" }).toString()).not.toBe(
      "gid://bcx/Person/5",
    );
  });

  it("new returns invalid gid when not checking", () => {
    // Rails: URI::GID.new(*URI.split('gid:///')) bypasses URI::GID.parse
    // validation. The Trails analog is constructing GID directly with
    // synthetic components — the parse path is skipped so no error is
    // raised even though the URI string is non-canonical.
    const synthetic = new GID("gid:///", {
      app: "",
      modelName: "",
      modelId: "",
      params: {},
    });
    expect(synthetic).toBeTruthy();
  });
});

describe("URI::GIDModelIDEncodingTest", () => {
  it("alphanumeric", () => {
    const uri = GID.build({ app: "app", modelName: "Person", modelId: "John123" }).toString();
    expect(uri).toBe("gid://app/Person/John123");
  });

  it("non-alphanumeric", () => {
    const uri = GID.build({
      app: "app",
      modelName: "Person",
      modelId: "John Doe-Smith/Jones",
    }).toString();
    expect(uri).toBe("gid://app/Person/John+Doe-Smith%2FJones");
  });

  it("every part of composite primary key is encoded", () => {
    const uri = GID.build({
      app: "app",
      modelName: "CompositePrimaryKeyModel",
      modelId: ["tenant key", "id value"],
    }).toString();
    expect(uri).toBe("gid://app/CompositePrimaryKeyModel/tenant+key/id+value");
  });
});

describe("URI::GIDModelIDDecodingTest", () => {
  it("alphanumeric", () => {
    expect(GID.parse("gid://app/Person/John123").modelId).toBe("John123");
  });

  it("non-alphanumeric", () => {
    expect(GID.parse("gid://app/Person/John+Doe-Smith%2FJones").modelId).toBe(
      "John Doe-Smith/Jones",
    );
  });

  it("every part of composite primary key is decoded", () => {
    const gid = GID.parse("gid://app/CompositePrimaryKeyModel/tenant+key+value/id+value");
    expect(gid.modelId).toEqual(["tenant key value", "id value"]);
  });
});

describe("URI::GIDValidationTest", () => {
  it("missing app", () => {
    assertInvalidComponent("gid:///Person/1");
  });

  it("missing path", () => {
    assertInvalidComponent("gid://bcx/");
  });

  it("missing model id", () => {
    const err = assertRaise(MissingModelIdError, () => GID.parse("gid://bcx/Person"));
    expect(err.message).toMatch(/Unable to create a Global ID for Person/);
  });

  it("missing model composite id", () => {
    const err = assertRaise(MissingModelIdError, () =>
      GID.parse("gid://bcx/CompositePrimaryKeyModel"),
    );
    expect(err.message).toMatch(/Unable to create a Global ID for CompositePrimaryKeyModel/);
  });

  it("empty", () => {
    assertInvalidComponent("gid:///");
  });

  it("invalid schemes", () => {
    assertBadUri("http://bcx/Person/5");
    assertBadUri("gyd://bcx/Person/5");
    assertBadUri("//bcx/Person/5");
  });
});

describe("URI::GIDAppValidationTest", () => {
  it("nil or blank apps are invalid", () => {
    assertInvalidApp(null);
    assertInvalidApp("");
  });

  it("apps containing non alphanumeric characters are invalid", () => {
    assertInvalidApp("foo&bar");
    assertInvalidApp("foo:bar");
    assertInvalidApp("foo_bar");
  });

  it("app with hyphen is allowed", () => {
    expect(validateApp("foo-bar")).toBe("foo-bar");
  });
});

describe("URI::GIDParamsTest", () => {
  it("indifferent key access", () => {
    const uri = GID.build({
      app: "bcx",
      modelName: "Person",
      modelId: "5",
      params: { hello: "world" },
    }).toString();
    const gid = GID.parse(uri);
    // Rails asserts both `params[:hello]` and `params['hello']` — a Ruby
    // Symbol key is a plain JS string here, so both arms read the same key.
    expect(gid.params["hello"]).toBe("world");
    expect(gid.params["hello"]).toBe("world");
  });

  it("integer option", () => {
    const uri = GID.build({
      app: "bcx",
      modelName: "Person",
      modelId: "5",
      params: { integer: "20" },
    }).toString();
    const gid = GID.parse(uri);
    expect(gid.params["integer"]).toBe("20");
  });

  it("multi value params returns last value", () => {
    const gid = GID.parse("gid://bcx/Person/5?multi=one&multi=two");
    expect(gid.params["multi"]).toBe("two");
  });

  it("as String", () => {
    const uri = GID.build({
      app: "bcx",
      modelName: "Person",
      modelId: "5",
      params: { hello: "world" },
    }).toString();
    expect(uri).toBe("gid://bcx/Person/5?hello=world");
  });

  it("immutable params", () => {
    // Rails: mutating @gid.params doesn't affect @gid.to_s, because to_s
    // returns the URI string fixed at construction time. Trails: toString()
    // returns the cached uri, so post-construction params writes don't
    // leak into the rendered URI either.
    const gid = GID.parse("gid://bcx/Person/5?hello=world");
    gid.params["param"] = "value";
    expect(gid.toString()).not.toBe("gid://bcx/Person/5?hello=world&param=value");
  });
});

describe("URI::GID class wrapper", () => {
  it("GID.parse exposes app / modelName / modelId / params", () => {
    const gid = GID.parse("gid://bcx/Person/5?hello=world");
    expect(gid.app).toBe("bcx");
    expect(gid.modelName).toBe("Person");
    expect(gid.modelId).toBe("5");
    expect(gid.params).toEqual({ hello: "world" });
    expect(gid.toString()).toBe("gid://bcx/Person/5?hello=world");
  });

  it("GID.create builds from app + model instance", () => {
    const gid = GID.create("bcx", { id: 5, constructor: { name: "Person" } });
    expect(gid.toString()).toBe("gid://bcx/Person/5");
  });

  it("GID.build accepts a components-hash with composite primary key", () => {
    const gid = GID.build({
      app: "bcx",
      modelName: "CompositePrimaryKeyModel",
      modelId: ["tenant", "id"],
      params: { db: "primary" },
    });
    expect(gid.toString()).toBe("gid://bcx/CompositePrimaryKeyModel/tenant/id?db=primary");
    expect(gid.modelId).toEqual(["tenant", "id"]);
  });

  it("GID.validateApp rejects invalid app names", () => {
    expect(() => GID.validateApp(null)).toThrow();
    expect(() => GID.validateApp("foo_bar")).toThrow();
    expect(GID.validateApp("foo-bar")).toBe("foo-bar");
  });

  it("GID#deconstructKeys returns a deep-enough copy of the component hash", () => {
    const gid = GID.parse("gid://bcx/Person/5?k=v");
    const a = gid.deconstructKeys();
    expect(a).toEqual({ app: "bcx", modelName: "Person", modelId: "5", params: { k: "v" } });
    // Mutating any field of the returned object must not affect the GID.
    (a as { app: string }).app = "evil";
    a.params["k"] = "evil";
    expect(gid.app).toBe("bcx");
    expect(gid.params).toEqual({ k: "v" });
  });

  it("GID#deconstructKeys also copies composite modelId arrays", () => {
    const gid = GID.parse("gid://bcx/CompositePrimaryKeyModel/tenant/id");
    const a = gid.deconstructKeys();
    expect(a.modelId).toEqual(["tenant", "id"]);
    (a.modelId as string[]).push("evil");
    expect(gid.modelId).toEqual(["tenant", "id"]);
  });
});
